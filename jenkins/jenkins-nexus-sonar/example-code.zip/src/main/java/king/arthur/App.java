package king.arthur;

import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) throws ParseException {
		System.out.println("Hello World!");

		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println(df.format(new Date()));
		String ljtest=df.format(new Date());
		System.out.println(ljtest.split(" ")[0]+"T"+ljtest.split(" ")[1]+"Z");
		
		System.out.println(df.format(new Date(System.currentTimeMillis() - 24*60*60*1000)) );
	}

}
