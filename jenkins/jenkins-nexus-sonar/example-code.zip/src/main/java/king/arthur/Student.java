package king.arthur;

public class Student {
    public boolean canVote(int age) {
    	print();
          if (age <= 0)
                 throw new IllegalArgumentException("age should be +ve");
          if (age < 18)
               return false;
          else
              return true;
    }
    
    private void print(){
    	System.out.println(11);
    }
}
