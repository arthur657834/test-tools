package king.arthur;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;


public class StudentTest {
	Student s = new Student();

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void testcanVote01() {
		Assert.assertEquals(true, s.canVote(18));
		Assert.assertTrue(s.canVote(18));
	}

	@Test
	public void testcanVote02() {
		Assert.assertEquals(false, s.canVote(17));
		Assert.assertFalse(s.canVote(17));

	}

	@Test(expected = IllegalArgumentException.class)
	public void testcanVote03() {
		s.canVote(0);
	}

	@Test
	public void testcanVote04() {
		boolean t = false;
		try {
			s.canVote(0);
		} catch (IllegalArgumentException e) {
			t = true;
		}
		Assert.assertTrue(t);

	}

	@Test
	public void testcanVote05() {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("age should be effective");
		s.canVote(0);
	}
}